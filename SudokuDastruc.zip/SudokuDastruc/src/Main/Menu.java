//package Main;
//
//import java.awt.*;
//
//import static Main.Sudoku.*;
//
//public class Menu {
//    protected void paintComponent(Graphics g) {
//        super.paintComponent(g);
//        draw(g);
//    }
//
//    private void draw(Graphics g) {
//    }
//
//    public void start() {
//        draw(g);
//    }
//}
